import 'holiday_data.dart';

class HolidayItem {
  List<Holiday> holidayList;
  String month;
}