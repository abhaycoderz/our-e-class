export enum UserType {
    STUDENT = "STUDENT",
    TEACHER = "TEACHER",
    PARENT = "PARENT",
    UNKNOWN = "UNKNOWN"
}
